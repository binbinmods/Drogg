# 0.1.4

Nerfed Permafrost

Card type changes now work for events too

# 0.1.3

Frozen Bulwark crash fixed

# 0.1.2

Permafrost is no longer a mage card.

# 0.1.1

Changed Permafrost from crack to chill

Frozen Bulwark now targets randomly on ties

Rimehurl now targets randomly properly

# 0.1.0

Initial concenpt
