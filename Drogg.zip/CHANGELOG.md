# 0.1.4

AutoUnlock enabled

# 0.1.3

Updated enchantments for balancing

# 0.1.2

Updated enchantments to proper targeting

# 0.1.1

Initial bug fixes and text updates

# 0.1.0

Initial concenpt
