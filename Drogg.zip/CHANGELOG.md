# 0.1.1

Changed Permafrost from crack to chill

Frozen Bulwark now targets randomly on ties

# 0.1.0

Initial concenpt
